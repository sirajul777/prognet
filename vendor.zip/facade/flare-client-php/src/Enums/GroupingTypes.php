<?php

namespace Facade\FlareClient\Enums;

class GroupingTypes
{
    const TOP_FRAME = 'topFrame';

    const EXCEPTION = 'exceptionClass';
}
