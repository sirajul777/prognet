@extends('layout')

@section('pagetitle','Welcome Page')

@section('title','Welcome')

@section('contents')
    
@endsection