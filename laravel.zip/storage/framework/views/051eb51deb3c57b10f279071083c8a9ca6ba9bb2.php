<?php $__env->startSection('pagetitle','Edit Data'); ?>

<?php $__env->startSection('title','Perubahan data'); ?>

<?php $__env->startSection('contents'); ?>
    <form action="/biodata/<?php echo e($biodata->id); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PUT')); ?>

        <p>Nama : <input type="text" name="nama" value="<?php echo e($biodata->nama); ?>"></p>
        <p>Alamat : <input type="text" name="alamat" value="<?php echo e($biodata->alamat); ?>"></p>
        <p><input type="submit" name="submit" value="Simpan"></p>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/latihan/laravel7.0/resources/views/editform.blade.php ENDPATH**/ ?>