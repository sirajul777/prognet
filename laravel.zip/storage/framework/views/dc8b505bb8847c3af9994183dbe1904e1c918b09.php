<?php $__env->startSection('pagetitle','New Data'); ?>

<?php $__env->startSection('title','Input data baru'); ?>

<?php $__env->startSection('contents'); ?>
    <form action="/biodata" method="POST">
        <?php echo csrf_field(); ?>
        <p>Nama : <input type="text" name="nama"></p>
        <p>Alamat : <input type="text" name="alamat"></p>
        <p><input type="submit" name="submit" value="Simpan"></p>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/latihan/laravel7.0/resources/views/new.blade.php ENDPATH**/ ?>