<?php $__env->startSection('pagetitle','Welcome Page'); ?>

<?php $__env->startSection('title','Welcome'); ?>

<?php $__env->startSection('contents'); ?>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/latihan/laravel7.0/resources/views/welcome.blade.php ENDPATH**/ ?>