<?php $__env->startSection('pagetitle','List Biodata'); ?>

<?php $__env->startSection('title','Daftar Biodata'); ?>

<?php $__env->startSection('contents'); ?>
    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Alamat</th>
            <th>Action</th>
        </tr>
        <?php $__currentLoopData = $biodata; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($b->id); ?></td>
                <td><?php echo e($b->nama); ?></td>
                <td><?php echo e($b->alamat); ?></td>
                <td><a href="/biodata/<?php echo e($b->id); ?>/edit">Edit</a></td>
                <td>
                    <form action="/biodata/<?php echo e($b->id); ?>" method="POST"> 
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        <input type="submit" name="submit" value="Delete">
                    </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/latihan/laravel7.0/resources/views/list.blade.php ENDPATH**/ ?>