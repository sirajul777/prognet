
<?php $__env->startSection('title','detail'); ?>
<?php $__env->startSection('titleContent','Detail kontak hobbies '); ?>

<?php $__env->startSection('mid'); ?>

<div class="table-responsive">
<table class="table table-warning table-triped text-center">
    <tr>
        <th>no</th>
        <th>Nama</th>
        <th>Hobby</th>
        <th>opsi</th>
    </tr>
    <?php 

    $no = 1;
    
    ?>
        <?php $__currentLoopData = $k; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="table-dark"><?= $no++ ?></td>
                <td class="table-dark"><?php echo e($k->nama); ?></td>
                <td class="table-dark">
                    <ul>
                        <?php $__currentLoopData = $k->hobby; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hoby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($hoby): ?>
                                <li> <?php echo e($hoby->hobby); ?> </li>
                            <?php else: ?>
                            None
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                       
                    </ul>
                </td>
                <td class="table-dark">
                        <button type="button" id="<?php echo e($k->id); ?>" class="btn btn-info editHob" data-toggle="modal" data-target="#editkh">Edit</button>
                        
                        <button type="submit" id="<?php echo e($k->id); ?>" class="btn btn-success tamHobby" data-target="#tambah" data-toggle="modal">Tambah</button>
                </td>               
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</div>  
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>

    <!-- Button trigger modal -->
<div class="modal fade" id="tambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Tambah hobby</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="tamkonhob" action="<?php echo e(route('kontak-hobbies.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <input type="text" hidden id="idkonHob" name="idkonHob">
            <div class="mb-3">
                <label for="hobby" class="form-label">hobby</label>
                <select class="form-select" aria-label="Default select example" name="hobby" required>
                    <option value="" selected disable>Pilih Hobby</option>
                    <?php $__currentLoopData = $h; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->hobby); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            
        </form>
      </div>
     
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<!-- Edit kh Modal -->
<div class="modal fade" id="editkh" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert Data Baru</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="updatekh" action="<?php echo e(route('kontak-hobbies.update',$k)); ?>" method="POST">
            <?php echo csrf_field(); ?>
             <?php echo e(method_field('PUT')); ?>

            <input type="text" hidden id="idkh" name="idkh">
            <?php $__currentLoopData = $k->hobby; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" name="isian[]" value="<?php echo e($item->id); ?>">
                        <label class="form-check-label" for="flexCheckDefault">
                            <?php echo e($item->hobby); ?> <small>isian[<?php echo e($item->id); ?>]</small>
                        </label>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary edit" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-danger">Delete</button>
            </div>
        </form>
      </div>
     
    </div>
  </div>
</div>
<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\laravel7.0\resources\views/kontaks/kontakHobby.blade.php ENDPATH**/ ?>