
<?php $__env->startSection('title','Hoby'); ?>
<?php $__env->startSection('titleContent','List Hoby'); ?>

<?php $__env->startSection('mid'); ?>

<div class="table-responsive">
<table class="table table-warning table-triped text-center">
    <tr>
        <th>no</th>
        <th>hobby</th>
        <th>opsi</th>
    </tr>
    <?php 

    $no = 1;
    
    ?>
        <?php $__currentLoopData = $hobby; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hobby): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td class="table-dark"><?= $no++ ?></td>
                <td class="table-dark"><?php echo e($hobby->hobby); ?></td>
                <td class="table-dark">
                    <form action="/hobby/<?php echo e($hobby->id); ?>" method="POST"> 
                        <button type="button" id="<?php echo e($hobby->id); ?>" class="btn btn-info editHobby" data-toggle="modal" data-target="#editHobby">Edit</button>
                        
                        <?php echo csrf_field(); ?>
                        <?php echo e(method_field('DELETE')); ?>

                        <button type="submit" class="btn btn-danger">Delete</button>
                    </form>
                </td>
                    
            
                
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
    </table>
</div>  
<?php $__env->stopSection(); ?>


<?php $__env->startSection('modal'); ?>
    
    <!-- Button trigger modal -->
<button type="button" class="btn btn-success mb-5" data-toggle="modal" data-target="#exampleModal">
  Insert Data
</button>
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Insert Data Baru</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form action="<?php echo e(route('hobby.store')); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="mb-3">
                <label for="hobby" class="form-label">Nama Hoby</label>
                <input type="text" name="hobby" class="form-control" id="hobby" aria-describedby="emailHelp" required>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary edit" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            
        </form>
      </div>
     
    </div>
  </div>
</div>


<?php $__env->stopSection(); ?>
<!-- Edit hobby Modal -->
<div class="modal fade" id="editHobby" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Hobby</h5>
        <button type="button" class="btn-close" data-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form id="updateHobby" action="<?php echo e(route('hobby.update',$hobby)); ?>" method="POST">
            <?php echo csrf_field(); ?>
             <?php echo e(method_field('PUT')); ?>

            <input type="text" hidden id="idHobby" name="idHobby">
            <div class="mb-3">
                <label for="hobby" class="form-label">Nama Hoby</label>
                <input type="text" name="editHobby" class="form-control" id="editHobby" aria-describedby="emailHelp" required>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary edit" data-dismiss="modal">Close</button>
                <button type="submit" class="btn btn-primary">Save changes</button>
            </div>
            
        </form>
      </div>
     
    </div>
  </div>
</div>
<?php echo $__env->make('layout.apps', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\LENOVO\Desktop\laravel7.0\resources\views/kontaks/hobby.blade.php ENDPATH**/ ?>