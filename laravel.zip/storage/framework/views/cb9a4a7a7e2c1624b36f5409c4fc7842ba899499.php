<div class="container-fluid">
      <div class="row">
        
        <nav id="sidebarMenu" class="sidebar collapse col-md-3 col-lg-2 d-md-block bg-dark">
          <div class="position-sticky pt-3">
            <ul class="nav flex-column">
              <li class="nav-item">
                <a class="nav-link" id="menu-kontak" href="<?php echo e('/kontak'); ?>">
                  Kontak
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="menu-hobby" href="<?php echo e('/hobby'); ?>">
                  Hobbies
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="menu-hobby" href="<?php echo e('/golonganDarah'); ?>">
                  Golongan Darah
                </a>
              </li>
              <li class="nav-item">
                <a class="nav-link" id="menu-hobby" href="<?php echo e('/kontak-hobbies'); ?>">
                  Kontak x Hobbies
                </a>
              </li>
            </ul>
          </div>
        </nav>

        
        
        <main class="col-md-9 ml-sm-auto col-lg-10 px-md-4">
            <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                <div class="col-md-9 col-lg-10">
                    <h1 class="text-center"><?php echo $__env->yieldContent('titleContent'); ?></h1>
                    <?php echo $__env->yieldContent('modal'); ?>
                    <?php echo $__env->yieldContent('mid'); ?>
                </div>
            </div>
        </main>
        
      </div>
    </div><?php /**PATH C:\Users\LENOVO\Desktop\laravel7.0\resources\views/layout/content.blade.php ENDPATH**/ ?>