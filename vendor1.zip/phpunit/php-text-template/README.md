# Text_Template

## Installation

## Installation

To add this package as a local, per-project dependency to your project, simply add a dependency on `phpunit/php-text-template` to your project's `composer.json` file. Here is a minimal example of a `composer.json` file that just defines a dependency on Text_Template:

    {
        "require": {
            "phpunit/php-text-template": "~1.2"
        }
    }

